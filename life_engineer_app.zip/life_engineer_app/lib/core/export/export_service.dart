import 'dart:convert';
import 'dart:io';
import 'package:csv/csv.dart';
import 'package:path_provider/path_provider.dart';
import '../database/app_database.dart';

class ExportService {
  static const tables = [
    'goals',
    'goal_logs',
    'habits',
    'habit_logs',
    'tasks',
    'transactions',
    'clients',
    'visits',
    'vehicles',
    'vehicle_maintenance',
    'daily_reviews',
  ];

  Future<File> exportJson() async {
    final directory = await getApplicationDocumentsDirectory();
    final data = <String, dynamic>{
      'app': 'Life Engineer',
      'exported_at': DateTime.now().toIso8601String(),
      'schema_version': 1,
    };

    for (final table in tables) {
      data[table] = await AppDatabase.instance.query(table);
    }

    final file = File(
      '${directory.path}/life_engineer_${DateTime.now().millisecondsSinceEpoch}.json',
    );
    return file.writeAsString(
      const JsonEncoder.withIndent('  ').convert(data),
    );
  }

  Future<Directory> exportCsv() async {
    final base = await getApplicationDocumentsDirectory();
    final directory = Directory(
      '${base.path}/life_engineer_csv_${DateTime.now().millisecondsSinceEpoch}',
    );
    await directory.create(recursive: true);

    for (final table in tables) {
      final rows = await AppDatabase.instance.query(table);
      if (rows.isEmpty) continue;
      final headers = rows.first.keys.toList();
      final csvRows = <List<dynamic>>[
        headers,
        ...rows.map((row) => headers.map((h) => row[h]).toList()),
      ];
      await File('${directory.path}/$table.csv').writeAsString(
        const ListToCsvConverter().convert(csvRows),
      );
    }
    return directory;
  }
}
