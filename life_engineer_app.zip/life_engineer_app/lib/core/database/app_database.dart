import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

class AppDatabase {
  AppDatabase._();
  static final AppDatabase instance = AppDatabase._();

  Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _open();
    return _database!;
  }

  Future<Database> _open() async {
    final dbPath = await getDatabasesPath();
    return openDatabase(
      join(dbPath, 'life_engineer.db'),
      version: 1,
      onConfigure: (db) async => db.execute('PRAGMA foreign_keys = ON'),
      onCreate: _create,
    );
  }

  Future<void> _create(Database db, int version) async {
    await db.execute('''
      CREATE TABLE goals (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        target_value REAL DEFAULT 100,
        current_value REAL DEFAULT 0,
        unit TEXT DEFAULT '%',
        start_date TEXT,
        due_date TEXT,
        status TEXT DEFAULT 'active',
        priority INTEGER DEFAULT 2,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE goal_logs (
        id TEXT PRIMARY KEY,
        goal_id TEXT NOT NULL,
        log_date TEXT NOT NULL,
        minutes INTEGER DEFAULT 0,
        progress_delta REAL DEFAULT 0,
        achievement TEXT,
        obstacle TEXT,
        next_step TEXT,
        rating INTEGER,
        created_at TEXT NOT NULL,
        FOREIGN KEY(goal_id) REFERENCES goals(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE habits (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        category TEXT NOT NULL,
        habit_type TEXT NOT NULL,
        target_value REAL DEFAULT 1,
        unit TEXT DEFAULT 'مرة',
        frequency TEXT DEFAULT 'daily',
        active_days TEXT DEFAULT '1,2,3,4,5,6,7',
        reminder_time TEXT,
        linked_goal_id TEXT,
        is_active INTEGER DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE habit_logs (
        id TEXT PRIMARY KEY,
        habit_id TEXT NOT NULL,
        log_date TEXT NOT NULL,
        value REAL DEFAULT 0,
        completed INTEGER DEFAULT 0,
        note TEXT,
        created_at TEXT NOT NULL,
        UNIQUE(habit_id, log_date),
        FOREIGN KEY(habit_id) REFERENCES habits(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE tasks (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        description TEXT,
        category TEXT,
        priority INTEGER DEFAULT 2,
        status TEXT DEFAULT 'planned',
        planned_date TEXT,
        due_date TEXT,
        estimated_minutes INTEGER DEFAULT 0,
        actual_minutes INTEGER DEFAULT 0,
        progress REAL DEFAULT 0,
        goal_id TEXT,
        client_id TEXT,
        project_id TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE transactions (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        amount REAL NOT NULL,
        currency TEXT DEFAULT 'YER',
        category TEXT NOT NULL,
        account TEXT DEFAULT 'نقدي',
        transaction_date TEXT NOT NULL,
        description TEXT,
        is_business INTEGER DEFAULT 0,
        client_id TEXT,
        project_id TEXT,
        receipt_path TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE clients (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        company TEXT,
        phone TEXT,
        location TEXT,
        contact_person TEXT,
        industry TEXT,
        rating INTEGER DEFAULT 3,
        payment_speed INTEGER DEFAULT 3,
        notes TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE visits (
        id TEXT PRIMARY KEY,
        client_id TEXT NOT NULL,
        equipment_name TEXT,
        visit_date TEXT NOT NULL,
        arrival_time TEXT,
        departure_time TEXT,
        reason TEXT,
        fault_description TEXT,
        diagnosis TEXT,
        action_taken TEXT,
        progress REAL DEFAULT 0,
        solved INTEGER DEFAULT 0,
        recommendations TEXT,
        visit_fee REAL DEFAULT 0,
        expenses REAL DEFAULT 0,
        paid_amount REAL DEFAULT 0,
        next_visit_date TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(client_id) REFERENCES clients(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE vehicles (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        make TEXT,
        model TEXT,
        year INTEGER,
        plate_number TEXT,
        odometer REAL DEFAULT 0,
        created_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE vehicle_maintenance (
        id TEXT PRIMARY KEY,
        vehicle_id TEXT NOT NULL,
        maintenance_type TEXT NOT NULL,
        maintenance_date TEXT NOT NULL,
        odometer REAL DEFAULT 0,
        cost REAL DEFAULT 0,
        workshop TEXT,
        next_date TEXT,
        next_odometer REAL,
        notes TEXT,
        created_at TEXT NOT NULL,
        FOREIGN KEY(vehicle_id) REFERENCES vehicles(id) ON DELETE CASCADE
      )
    ''');

    await db.execute('''
      CREATE TABLE daily_reviews (
        id TEXT PRIMARY KEY,
        review_date TEXT NOT NULL UNIQUE,
        achievements TEXT,
        unfinished TEXT,
        blockers TEXT,
        lessons TEXT,
        tomorrow_plan TEXT,
        sleep_hours REAL,
        energy INTEGER,
        mood INTEGER,
        stress INTEGER,
        work_minutes INTEGER DEFAULT 0,
        family_minutes INTEGER DEFAULT 0,
        learning_minutes INTEGER DEFAULT 0,
        day_score REAL DEFAULT 0,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');
  }

  Future<List<Map<String, Object?>>> query(
    String table, {
    String? where,
    List<Object?>? whereArgs,
    String? orderBy,
    int? limit,
  }) async {
    final db = await database;
    return db.query(
      table,
      where: where,
      whereArgs: whereArgs,
      orderBy: orderBy,
      limit: limit,
    );
  }

  Future<int> insert(String table, Map<String, Object?> values) async {
    final db = await database;
    return db.insert(
      table,
      values,
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<int> update(
    String table,
    Map<String, Object?> values,
    String id,
  ) async {
    final db = await database;
    return db.update(table, values, where: 'id = ?', whereArgs: [id]);
  }

  Future<int> delete(String table, String id) async {
    final db = await database;
    return db.delete(table, where: 'id = ?', whereArgs: [id]);
  }
}
