import 'package:flutter/material.dart';
import '../../core/database/app_database.dart';

class VisitsPage extends StatefulWidget {
  const VisitsPage({super.key});

  @override
  State<VisitsPage> createState() => _VisitsPageState();
}

class _VisitsPageState extends State<VisitsPage> {
  List<Map<String, Object?>> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    items = await AppDatabase.instance.query('visits', orderBy: 'visit_date DESC');
    if (mounted) setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('زيارات العمل')),
      body: items.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(30),
                child: Text(
                  'لا توجد زيارات مسجلة بعد.\nستتم إضافة نموذج زيارة فني متكامل في المرحلة التالية.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.builder(
              itemCount: items.length,
              itemBuilder: (_, index) => ListTile(
                title: Text(items[index]['equipment_name']?.toString() ?? 'زيارة فنية'),
                subtitle: Text(items[index]['visit_date'].toString()),
              ),
            ),
    );
  }
}
