import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/app_database.dart';

class ClientsPage extends StatefulWidget {
  const ClientsPage({super.key});

  @override
  State<ClientsPage> createState() => _ClientsPageState();
}

class _ClientsPageState extends State<ClientsPage> {
  List<Map<String, Object?>> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    items = await AppDatabase.instance.query('clients', orderBy: 'created_at DESC');
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final name = TextEditingController();
    final company = TextEditingController();
    final phone = TextEditingController();
    final location = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('عميل جديد'),
        content: SingleChildScrollView(
          child: Column(
            children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'اسم العميل')),
              const SizedBox(height: 10),
              TextField(controller: company, decoration: const InputDecoration(labelText: 'المصنع أو الشركة')),
              const SizedBox(height: 10),
              TextField(controller: phone, decoration: const InputDecoration(labelText: 'رقم الهاتف')),
              const SizedBox(height: 10),
              TextField(controller: location, decoration: const InputDecoration(labelText: 'الموقع')),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty) {
      final now = DateTime.now().toIso8601String();
      await AppDatabase.instance.insert('clients', {
        'id': const Uuid().v4(),
        'name': name.text.trim(),
        'company': company.text.trim(),
        'phone': phone.text.trim(),
        'location': location.text.trim(),
        'rating': 3,
        'payment_speed': 3,
        'created_at': now,
        'updated_at': now,
      });
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('العملاء والمصانع')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add_business),
        label: const Text('عميل'),
      ),
      body: items.isEmpty
          ? const Center(child: Text('أضف أول عميل أو مصنع.'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                return Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.factory)),
                    title: Text(item['name'].toString()),
                    subtitle: Text(
                      [item['company'], item['location']]
                          .where((e) => e != null && e.toString().isNotEmpty)
                          .join(' • '),
                    ),
                    trailing: const Icon(Icons.chevron_left),
                  ),
                );
              },
            ),
    );
  }
}
