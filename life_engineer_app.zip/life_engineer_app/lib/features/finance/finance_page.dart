import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/app_database.dart';

class FinancePage extends StatefulWidget {
  const FinancePage({super.key});

  @override
  State<FinancePage> createState() => _FinancePageState();
}

class _FinancePageState extends State<FinancePage> {
  List<Map<String, Object?>> items = [];
  double income = 0;
  double expense = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    items = await AppDatabase.instance.query(
      'transactions',
      orderBy: 'transaction_date DESC, created_at DESC',
      limit: 100,
    );
    income = 0;
    expense = 0;
    for (final item in items) {
      final amount = (item['amount'] as num).toDouble();
      if (item['type'] == 'income') {
        income += amount;
      } else {
        expense += amount;
      }
    }
    if (mounted) setState(() {});
  }

  Future<void> _add(String type) async {
    final amount = TextEditingController();
    final description = TextEditingController();
    String category = type == 'income' ? 'زيارة صيانة' : 'مواصلات';

    final ok = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.fromLTRB(
          16,
          20,
          16,
          MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: StatefulBuilder(
          builder: (context, setModalState) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                type == 'income' ? 'إضافة دخل' : 'إضافة مصروف',
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 16),
              TextField(
                controller: amount,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: 'المبلغ'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: description,
                decoration: const InputDecoration(labelText: 'الوصف'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: TextEditingController(text: category),
                decoration: const InputDecoration(labelText: 'التصنيف'),
                onChanged: (v) => category = v,
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () => Navigator.pop(context, true),
                child: const Text('حفظ'),
              ),
            ],
          ),
        ),
      ),
    );

    final parsed = double.tryParse(amount.text);
    if (ok == true && parsed != null) {
      await AppDatabase.instance.insert('transactions', {
        'id': const Uuid().v4(),
        'type': type,
        'amount': parsed,
        'currency': 'YER',
        'category': category,
        'account': 'نقدي',
        'transaction_date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
        'description': description.text.trim(),
        'is_business': 0,
        'created_at': DateTime.now().toIso8601String(),
      });
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المال والميزانية')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _add('expense'),
        child: const Icon(Icons.remove),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(child: _summary('الدخل', income, Icons.south_west)),
              const SizedBox(width: 10),
              Expanded(child: _summary('المصروف', expense, Icons.north_east)),
            ],
          ),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => _add('income'),
            icon: const Icon(Icons.add),
            label: const Text('إضافة دخل'),
          ),
          const SizedBox(height: 18),
          Text('آخر العمليات', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          if (items.isEmpty) const Center(child: Text('لا توجد عمليات مالية بعد.')),
          ...items.map(
            (item) => Card(
              child: ListTile(
                leading: CircleAvatar(
                  child: Icon(
                    item['type'] == 'income'
                        ? Icons.south_west
                        : Icons.north_east,
                  ),
                ),
                title: Text(item['category'].toString()),
                subtitle: Text(item['description']?.toString() ?? ''),
                trailing: Text(
                  '${item['type'] == 'income' ? '+' : '-'}${item['amount']}',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _summary(String label, double value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon),
            Text(value.toStringAsFixed(0), style: Theme.of(context).textTheme.headlineSmall),
            Text(label),
          ],
        ),
      ),
    );
  }
}
