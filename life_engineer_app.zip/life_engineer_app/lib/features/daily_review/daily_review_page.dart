import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/app_database.dart';

class DailyReviewPage extends StatefulWidget {
  const DailyReviewPage({super.key});

  @override
  State<DailyReviewPage> createState() => _DailyReviewPageState();
}

class _DailyReviewPageState extends State<DailyReviewPage> {
  final achievements = TextEditingController();
  final blockers = TextEditingController();
  final lessons = TextEditingController();
  final tomorrow = TextEditingController();
  double energy = 3;
  double mood = 3;

  Future<void> _save() async {
    final now = DateTime.now();
    final date = DateFormat('yyyy-MM-dd').format(now);
    await AppDatabase.instance.insert('daily_reviews', {
      'id': const Uuid().v4(),
      'review_date': date,
      'achievements': achievements.text.trim(),
      'blockers': blockers.text.trim(),
      'lessons': lessons.text.trim(),
      'tomorrow_plan': tomorrow.text.trim(),
      'energy': energy.round(),
      'mood': mood.round(),
      'stress': 3,
      'day_score': ((energy + mood) / 10) * 100,
      'created_at': now.toIso8601String(),
      'updated_at': now.toIso8601String(),
    });
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم حفظ مراجعة اليوم')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('مراجعة اليوم')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          TextField(
            controller: achievements,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'أهم ما أنجزته اليوم'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: blockers,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'العوائق والمشكلات'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: lessons,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'درس اليوم'),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: tomorrow,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'أهم خطوة للغد'),
          ),
          const SizedBox(height: 20),
          Text('الطاقة: ${energy.round()}/5'),
          Slider(value: energy, min: 1, max: 5, divisions: 4, onChanged: (v) => setState(() => energy = v)),
          Text('المزاج: ${mood.round()}/5'),
          Slider(value: mood, min: 1, max: 5, divisions: 4, onChanged: (v) => setState(() => mood = v)),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: _save,
            icon: const Icon(Icons.save),
            label: const Text('حفظ مراجعة اليوم'),
          ),
        ],
      ),
    );
  }
}
