import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/app_database.dart';

class HabitsPage extends StatefulWidget {
  const HabitsPage({super.key});

  @override
  State<HabitsPage> createState() => _HabitsPageState();
}

class _HabitsPageState extends State<HabitsPage> {
  List<Map<String, Object?>> items = [];
  Set<String> completed = {};

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final date = DateFormat('yyyy-MM-dd').format(DateTime.now());
    items = await AppDatabase.instance.query(
      'habits',
      where: 'is_active = 1',
      orderBy: 'created_at DESC',
    );
    final logs = await AppDatabase.instance.query(
      'habit_logs',
      where: 'log_date = ? AND completed = 1',
      whereArgs: [date],
    );
    completed = logs.map((e) => e['habit_id'].toString()).toSet();
    if (mounted) setState(() {});
  }

  Future<void> _toggle(Map<String, Object?> habit, bool value) async {
    final date = DateFormat('yyyy-MM-dd').format(DateTime.now());
    await AppDatabase.instance.insert('habit_logs', {
      'id': '${habit['id']}_$date',
      'habit_id': habit['id'],
      'log_date': date,
      'value': value ? 1 : 0,
      'completed': value ? 1 : 0,
      'note': null,
      'created_at': DateTime.now().toIso8601String(),
    });
    _load();
  }

  Future<void> _add() async {
    final name = TextEditingController();
    String category = 'صحة';
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('عادة جديدة'),
        content: StatefulBuilder(
          builder: (context, setDialogState) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: name,
                decoration: const InputDecoration(labelText: 'اسم العادة'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'التصنيف'),
                items: const ['صحة', 'تعلم', 'عمل', 'أسرة', 'روحاني', 'شخصي']
                    .map((e) => DropdownMenuItem(value: e, child: Text(e)))
                    .toList(),
                onChanged: (v) => setDialogState(() => category = v!),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && name.text.trim().isNotEmpty) {
      final now = DateTime.now().toIso8601String();
      await AppDatabase.instance.insert('habits', {
        'id': const Uuid().v4(),
        'name': name.text.trim(),
        'category': category,
        'habit_type': 'boolean',
        'target_value': 1,
        'unit': 'مرة',
        'frequency': 'daily',
        'active_days': '1,2,3,4,5,6,7',
        'is_active': 1,
        'created_at': now,
        'updated_at': now,
      });
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    final ratio = items.isEmpty ? 0.0 : completed.length / items.length;
    return Scaffold(
      appBar: AppBar(title: const Text('العادات')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('عادة'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  Text(
                    'التزام اليوم ${(ratio * 100).toStringAsFixed(0)}%',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 10),
                  LinearProgressIndicator(value: ratio),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (items.isEmpty)
            const Padding(
              padding: EdgeInsets.all(30),
              child: Center(child: Text('أضف أول عادة تريد متابعتها.')),
            ),
          ...items.map(
            (habit) => Card(
              child: CheckboxListTile(
                value: completed.contains(habit['id']),
                onChanged: (v) => _toggle(habit, v ?? false),
                title: Text(habit['name'].toString()),
                subtitle: Text(habit['category'].toString()),
                secondary: const Icon(Icons.repeat),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
