import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/export/export_service.dart';

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  Future<void> _exportJson(BuildContext context) async {
    final file = await ExportService().exportJson();
    if (!context.mounted) return;
    await Share.shareXFiles(
      [XFile(file.path)],
      text: 'نسخة بيانات تطبيق مهندس حياتي',
    );
  }

  Future<void> _exportCsv(BuildContext context) async {
    final directory = await ExportService().exportCsv();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('تم إنشاء ملفات CSV في:\n${directory.path}')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final sections = [
      ('المشاريع والمعدات', Icons.precision_manufacturing_outlined),
      ('صيانة السيارة', Icons.directions_car_outlined),
      ('الصحة', Icons.favorite_outline),
      ('الأسرة والالتزامات', Icons.family_restroom),
      ('التقارير والتحليلات', Icons.insights_outlined),
      ('الإعدادات والنسخ الاحتياطي', Icons.settings_outlined),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('المزيد')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ...sections.map(
            (section) => Card(
              child: ListTile(
                leading: CircleAvatar(child: Icon(section.$2)),
                title: Text(section.$1),
                subtitle: const Text('قيد البناء ضمن المراحل القادمة'),
                trailing: const Icon(Icons.chevron_left),
              ),
            ),
          ),
          const SizedBox(height: 20),
          Text('تصدير البيانات', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 10),
          FilledButton.icon(
            onPressed: () => _exportJson(context),
            icon: const Icon(Icons.data_object),
            label: const Text('تصدير JSON للتحليل بالذكاء الاصطناعي'),
          ),
          const SizedBox(height: 10),
          OutlinedButton.icon(
            onPressed: () => _exportCsv(context),
            icon: const Icon(Icons.table_view),
            label: const Text('تصدير جداول CSV'),
          ),
        ],
      ),
    );
  }
}
