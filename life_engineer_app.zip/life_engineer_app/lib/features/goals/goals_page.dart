import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/app_database.dart';

class GoalsPage extends StatefulWidget {
  const GoalsPage({super.key});

  @override
  State<GoalsPage> createState() => _GoalsPageState();
}

class _GoalsPageState extends State<GoalsPage> {
  List<Map<String, Object?>> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    items = await AppDatabase.instance.query(
      'goals',
      orderBy: 'created_at DESC',
    );
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final title = TextEditingController();
    final description = TextEditingController();
    String category = 'مهني';
    final result = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (context) => Padding(
        padding: EdgeInsets.fromLTRB(
          16,
          20,
          16,
          MediaQuery.of(context).viewInsets.bottom + 20,
        ),
        child: StatefulBuilder(
          builder: (context, setModalState) => Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text('هدف جديد', style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(height: 16),
              TextField(
                controller: title,
                decoration: const InputDecoration(labelText: 'اسم الهدف'),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: category,
                decoration: const InputDecoration(labelText: 'التصنيف'),
                items: const [
                  'مهني',
                  'مالي',
                  'تعليمي',
                  'صحي',
                  'أسري',
                  'شخصي',
                ].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (v) => setModalState(() => category = v!),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: description,
                maxLines: 3,
                decoration: const InputDecoration(labelText: 'لماذا هذا الهدف مهم؟'),
              ),
              const SizedBox(height: 16),
              FilledButton.icon(
                onPressed: () => Navigator.pop(context, true),
                icon: const Icon(Icons.save),
                label: const Text('حفظ'),
              ),
            ],
          ),
        ),
      ),
    );

    if (result == true && title.text.trim().isNotEmpty) {
      final now = DateTime.now().toIso8601String();
      await AppDatabase.instance.insert('goals', {
        'id': const Uuid().v4(),
        'title': title.text.trim(),
        'category': category,
        'description': description.text.trim(),
        'target_value': 100,
        'current_value': 0,
        'unit': '%',
        'status': 'active',
        'priority': 2,
        'created_at': now,
        'updated_at': now,
      });
      _load();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('الأهداف')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('هدف'),
      ),
      body: items.isEmpty
          ? const Center(child: Text('أضف أول هدف تريد العمل عليه.'))
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final item = items[index];
                final current = (item['current_value'] as num?)?.toDouble() ?? 0;
                final target = (item['target_value'] as num?)?.toDouble() ?? 100;
                final progress = target == 0 ? 0.0 : (current / target).clamp(0.0, 1.0);
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          item['title'].toString(),
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                fontWeight: FontWeight.bold,
                              ),
                        ),
                        Text(item['category'].toString()),
                        const SizedBox(height: 12),
                        LinearProgressIndicator(value: progress),
                        const SizedBox(height: 6),
                        Text('${(progress * 100).toStringAsFixed(0)}% إنجاز'),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
