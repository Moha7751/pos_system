import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../core/database/app_database.dart';

class TasksPage extends StatefulWidget {
  const TasksPage({super.key});

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> {
  List<Map<String, Object?>> items = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    items = await AppDatabase.instance.query('tasks', orderBy: 'created_at DESC');
    if (mounted) setState(() {});
  }

  Future<void> _add() async {
    final title = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('مهمة جديدة'),
        content: TextField(
          controller: title,
          decoration: const InputDecoration(labelText: 'المهمة'),
          autofocus: true,
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('حفظ')),
        ],
      ),
    );
    if (ok == true && title.text.trim().isNotEmpty) {
      final now = DateTime.now().toIso8601String();
      await AppDatabase.instance.insert('tasks', {
        'id': const Uuid().v4(),
        'title': title.text.trim(),
        'category': 'عام',
        'priority': 2,
        'status': 'planned',
        'planned_date': DateFormat('yyyy-MM-dd').format(DateTime.now()),
        'estimated_minutes': 30,
        'actual_minutes': 0,
        'progress': 0,
        'created_at': now,
        'updated_at': now,
      });
      _load();
    }
  }

  Future<void> _complete(Map<String, Object?> item, bool value) async {
    await AppDatabase.instance.update('tasks', {
      'status': value ? 'completed' : 'planned',
      'progress': value ? 100 : 0,
      'updated_at': DateTime.now().toIso8601String(),
    }, item['id'].toString());
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('المهام والوقت')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _add,
        icon: const Icon(Icons.add),
        label: const Text('مهمة'),
      ),
      body: items.isEmpty
          ? const Center(child: Text('لا توجد مهام بعد.'))
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: items.length,
              itemBuilder: (context, index) {
                final item = items[index];
                final done = item['status'] == 'completed';
                return Card(
                  child: CheckboxListTile(
                    value: done,
                    onChanged: (v) => _complete(item, v ?? false),
                    title: Text(
                      item['title'].toString(),
                      style: TextStyle(
                        decoration: done ? TextDecoration.lineThrough : null,
                      ),
                    ),
                    subtitle: Text(item['planned_date']?.toString() ?? ''),
                  ),
                );
              },
            ),
    );
  }
}
