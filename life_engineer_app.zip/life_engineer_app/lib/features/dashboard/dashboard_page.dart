import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../core/database/app_database.dart';
import '../../shared/widgets/metric_card.dart';
import '../../shared/widgets/section_card.dart';
import '../tasks/tasks_page.dart';
import '../clients/clients_page.dart';
import '../visits/visits_page.dart';
import '../daily_review/daily_review_page.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int goals = 0;
  int habits = 0;
  int tasks = 0;
  double todayExpenses = 0;
  double todayIncome = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final db = AppDatabase.instance;
    final date = DateFormat('yyyy-MM-dd').format(DateTime.now());
    final g = await db.query('goals', where: "status = 'active'");
    final h = await db.query('habits', where: 'is_active = 1');
    final t = await db.query(
      'tasks',
      where: "planned_date = ? AND status != 'completed'",
      whereArgs: [date],
    );
    final tr = await db.query(
      'transactions',
      where: 'transaction_date = ?',
      whereArgs: [date],
    );

    double expenses = 0;
    double income = 0;
    for (final item in tr) {
      final amount = (item['amount'] as num?)?.toDouble() ?? 0;
      if (item['type'] == 'expense') {
        expenses += amount;
      } else {
        income += amount;
      }
    }

    if (!mounted) return;
    setState(() {
      goals = g.length;
      habits = h.length;
      tasks = t.length;
      todayExpenses = expenses;
      todayIncome = income;
    });
  }

  void _open(Widget page) async {
    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => page),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    final today = DateFormat('EEEE، d MMMM', 'ar').format(DateTime.now());

    return Scaffold(
      appBar: AppBar(
        title: const Text('مهندس حياتي'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(today, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(
              'صمّم يومك، قِس تقدمك، وطوّر حياتك وعملك.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 18),
            SizedBox(
              height: 130,
              child: GridView.count(
                crossAxisCount: 2,
                childAspectRatio: 1.85,
                crossAxisSpacing: 10,
                mainAxisSpacing: 10,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  MetricCard(
                    label: 'أهداف نشطة',
                    value: '$goals',
                    icon: Icons.flag,
                  ),
                  MetricCard(
                    label: 'عادات للمتابعة',
                    value: '$habits',
                    icon: Icons.repeat,
                  ),
                  MetricCard(
                    label: 'مهام اليوم',
                    value: '$tasks',
                    icon: Icons.task_alt,
                  ),
                  MetricCard(
                    label: 'صافي اليوم',
                    value: (todayIncome - todayExpenses).toStringAsFixed(0),
                    icon: Icons.trending_up,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 22),
            Text(
              'إدارة اليوم',
              style: Theme.of(context).textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 10),
            SectionCard(
              title: 'المهام والوقت',
              icon: Icons.schedule,
              subtitle: 'خطط، تابع، وسجّل الوقت الفعلي.',
              badge: '$tasks اليوم',
              onTap: () => _open(const TasksPage()),
            ),
            const SizedBox(height: 10),
            SectionCard(
              title: 'العملاء',
              icon: Icons.factory_outlined,
              subtitle: 'ملفات المصانع والعملاء والدخل المستحق.',
              onTap: () => _open(const ClientsPage()),
            ),
            const SizedBox(height: 10),
            SectionCard(
              title: 'زيارات العمل',
              icon: Icons.engineering_outlined,
              subtitle: 'العطل، التشخيص، الإجراء، التكلفة والإنجاز.',
              onTap: () => _open(const VisitsPage()),
            ),
            const SizedBox(height: 10),
            SectionCard(
              title: 'مراجعة اليوم',
              icon: Icons.auto_stories_outlined,
              subtitle: 'ماذا أنجزت؟ ما العوائق؟ وما خطة الغد؟',
              onTap: () => _open(const DailyReviewPage()),
            ),
          ],
        ),
      ),
    );
  }
}
